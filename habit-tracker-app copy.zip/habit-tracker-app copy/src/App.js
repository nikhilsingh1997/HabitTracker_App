import Homepage from "./Pages/Homepage/Homepage.js";
import { Navbar } from "./Components/Navbar/Navbar.js";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import DetailsPage from "./Pages/DetailsPage/DetailsPage.js";




function App() {

  const router = createBrowserRouter([
    {
      path : "/", 
      element : <Navbar/>, 
      children : [
          {
            index : true, element : <Homepage/>
          },
          {
            path : "/detailsPage", element : <DetailsPage/>
          }
      ]
    },
  
  ])

  return (
    <RouterProvider router={router} />
  );
}

export default App;
