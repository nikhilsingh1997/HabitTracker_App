import { useEffect, useState } from "react";
import "./AddHabit.css";
import { addHabit, habitSelector, setSuggestedHabit } from "../../Redux/Reducer/habitReducer";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";


const AddHabit = ()=> {

    const [habit, setHabit] = useState("Sample Habit");
    const {habits, suggestedHabit} = useSelector(habitSelector);
    const dispatch = useDispatch();
     
    const handleSubmit = (e)=>{
        e.preventDefault();

        const createdDate = new Date();
        const weekDays = Array(7).fill(null);
        const data = {
                id : habits.length,
                name : habit,
                completedDays : 0,
                createdOn : `${createdDate.toDateString().slice(4,15)}`,
                weekDays,
                url : suggestedHabit ? `${suggestedHabit.url}` : "https://play-lh.googleusercontent.com/7cwJD9wRKPu1xnSomH7UI0ICAXT_lJt7JAJa76Nut0oYH__b2XvjaUUpJHQhhx41roA"
        }
        dispatch(addHabit(data));
        setHabit("");
        dispatch(setSuggestedHabit({}));
        toast.success("New habit added")
    }

    useEffect(()=>{
        if(suggestedHabit){
            setHabit(suggestedHabit.habit);
        }
    },[suggestedHabit]);


    return(
    <div className = "add-habit-container">
        <h2>Add your habit</h2>
        <div className = "form-container">
            <form onSubmit = {handleSubmit} >
                <label htmlFor="habit-input" style = {{fontSize : "larger"}}>Habit : </label>
                <br/>
                <input type = "text" 
                       value = {habit}
                       placeholder="Enter your habit" 
                       id = "habit-input" 
                       onChange = {(e)=>setHabit(e.target.value)}/>
                <br/>
                <button type = "submit" 
                         >    Add Habit
                </button>
            </form>
        </div>
    </div>
    )
}

export {AddHabit}