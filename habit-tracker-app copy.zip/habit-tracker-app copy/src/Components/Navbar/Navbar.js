import logo from "../../Assests/logo.png";
import { NavLink, Outlet } from "react-router-dom";
import "./Navbar.css"

const Navbar = ()=>{
    return(
        <>
        <div className="navbar-container">
           <img className="logo" src = {logo} alt = "habit-tacking-logo"/>
           <div id = "homepage-links" >
             {/* List of Links */}
             <ul>
                <li> 
                    <NavLink to = "/" style = {{marginRight : "0.9rem"}}>Home</NavLink>
                </li>
                <li> 
                    <NavLink to = "/detailsPage" >Your Habits</NavLink>
                </li>
             </ul>
           </div>
        </div>
        <Outlet/>
        </>
    )
}

export {Navbar};