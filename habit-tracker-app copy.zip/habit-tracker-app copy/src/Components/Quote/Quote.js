import { habitSelector } from "../../Redux/Reducer/habitReducer";
import { useSelector } from "react-redux";
import "./Quote.css";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { quoteFetchThunk } from "../../Redux/Reducer/habitReducer";

const Quote = ()=>{
    const {quote} = useSelector(habitSelector);
    const dispatch = useDispatch();

    useEffect( ()=> {
        dispatch(quoteFetchThunk())
    }, []);
    console.log("Quote", quote.text);
    return(
        <div className="quote-container" >
            <p id = "p1" >Quote of the day : </p>
                <p id = "quote" >"{quote.text}"</p>
            <p id = "p2" >by - {quote.author}</p>
        </div>
    )
}

export {Quote};