import { useDispatch } from "react-redux";
import { SuggestedHabit } from "../../Data/SuggestedHabits";
import "./Suggestions.css";
import { setSuggestedHabit } from "../../Redux/Reducer/habitReducer";

const Suggestions = ()=>{
    const dispatch = useDispatch();

    const handleSuggestedHabit = (item)=>{
        dispatch(setSuggestedHabit(item));
    }

    return(
        <div className="suggestions-container"  >
            <nav>Suggestions</nav>
            {SuggestedHabit.map((item, index)=>{
                return(
                    <div className="suggested-habit" onClick={()=>handleSuggestedHabit(item)} >
                            <div className="habit-name-image" >
                                {item.habit}
                                <img src = {item.url} alt = "habit"/>
                            </div>
                    </div>
                )
            })}
        </div>
    )
}

export {Suggestions};