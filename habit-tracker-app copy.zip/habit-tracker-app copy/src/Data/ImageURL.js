// list of motivational image's Url
// used to render a new image on each render of homepage

// array of image url
export const DisplayImage = [
    {
        url:'https://m.media-amazon.com/images/I/6148xVIsG4L._AC_UF894,1000_QL80_.jpg'
    },
    {
        url:'https://media.istockphoto.com/id/1411837419/photo/inspirational-quote-with-phrase-success-is-hidden-in-your-daily-routine.jpg?s=612x612&w=0&k=20&c=MmyvZcp8O9riYCNSOaQvh1ycMPcrQMzs65_TiN8Dfj8='
    },
    {
        url:'https://www.careerexperts.co.uk/wp-content/uploads/2017/07/Motivational-quotes-for-work-min.jpg'
    },
    {
        url:'https://wallpaperaccess.com/full/1691782.jpg'
    },
    {
        url:'https://www.betterteam.com/images/betterteam-motivational-quotes-for-the-workplace-5355x3570-20201119.jpeg?crop=2:1,smart&width=1200&dpr=2'
    },
    {
        url:'https://media.istockphoto.com/id/1390474768/photo/inspirational-and-motivational-quote.jpg?s=612x612&w=0&k=20&c=aGD7yNeI5YC03Hoy7sktDxrgyED0RYCmfVKQG49hLxM='
    },
    {
        url:'https://e1.pxfuel.com/desktop-wallpaper/80/586/desktop-wallpaper-motivational-quotes-for-work-backgrounds-motivation-work.jpg'
    },
    {
        url:'https://www.hdwallpapers.in/download/hard_work_pays_off_in_the_long_run_hd_motivational-1366x768.jpg'
    },
    {
        url:'https://w0.peakpx.com/wallpaper/779/345/HD-wallpaper-quotes-quotes-about-work-motivation-to-work-inspiration.jpg'
    },
    {
        url:'https://wallpapercave.com/wp/wp2132773.jpg'
    },
    {
        url:'https://cdn.quotesgram.com/img/53/47/1625213456-motivational-quotes-for-work-success---cool-inspirational-wallpaper-on-ego-and-talent--too-much-ego-will-kill-wallpaper-hd.png'
    },
    {
        url:'https://wallpaperaccess.com/full/668460.png'
    },
    {
        url:'https://live.staticflickr.com/2947/15173272989_8db95de4e4_b.jpg'
    }
]

