import "./DetailsPage.css";

export default function DetailsPage(){
    return(
        <div className="details-container" >
            <div id = "nav" >
                <p>Hey Champ !</p>
                <p> 31 July 2024</p>
            </div>
        </div>
    )
}