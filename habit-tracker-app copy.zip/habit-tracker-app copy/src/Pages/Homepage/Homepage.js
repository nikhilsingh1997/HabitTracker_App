import { AddHabit } from "../../Components/AddHabit/AddHabit";
import { Suggestions } from "../../Components/Suggestions/Suggestions";
import { Quote } from "../../Components/Quote/Quote";
import "./HomePage.css";
import { useSelector } from "react-redux";
import { habitSelector } from "../../Redux/Reducer/habitReducer";
import { useEffect, useState } from "react";

export default function Homepage(){
    const {displayImageURL, suggestedHabit } = useSelector(habitSelector);
    const [button, setButton] = useState(true);

    useEffect(()=>{
        if(suggestedHabit){
            setButton(false);
        }
    },[suggestedHabit])

    const toggle = ()=>{
        setButton(!button);
    }

    return(
        <div className="home-page" >
            <div className="add-habit" >
                <Quote/>
                <button id = "button1" onClick={toggle} style = {{"backgroundColor": button ? "#f7b279" :"#e14b4b"}} >{button ? "Add habit" : "Cancel"}</button>
                {button ? <img id = "motivational-image" src = {displayImageURL} alt = "motivational image"/> : <AddHabit /> }
            </div>
            <div className="suggestions">
            <Suggestions/>
            </div>
        </div>
    )
}