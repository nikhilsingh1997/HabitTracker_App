import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { DisplayImage } from "../../Data/ImageURL";
import { SuggestedHabit } from "../../Data/SuggestedHabits";

const initialState = {
    habits : [],
    quote : {},
    displayImageURL : "",
    suggestedHabit : {},
}


export const quoteFetchThunk = createAsyncThunk(
    "Quote",
    async(arg, thunkApi) =>{
        const response = await fetch("https://type.fit/api/quotes");
        const data = response.json();
        console.log("data",data);
        return data;
    }
);

const habitSlice = createSlice({
    name : "habitTracker",
    initialState,
    reducers :{
        addHabit : (state, action)=>{
            state.habits = [...state.habits, action.payload];
            console.log("H",state.habits);
        },
        setSuggestedHabit : (state, action) => {
            state.suggestedHabit = action.payload;
            console.log("S", state.suggestedHabit);
        }

    },
    extraReducers :(builder)=>{
        builder.addCase(quoteFetchThunk.fulfilled, (state, action)=>{
            const data = [...action.payload];
            console.log(data);
            const index = Math.trunc(Math.random()*12);
            state.quote = {...data[index]};
            state.displayImageURL = DisplayImage[index].url;
            console.log("quoteR",state.quote);
        })
    }
})

export const habitReducer = habitSlice.reducer;
export const habitSelector = (state)=> state.habitReducer;
export const {addHabit, setSuggestedHabit} = habitSlice.actions;